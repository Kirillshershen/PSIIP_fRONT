class Car {
    constructor(brand, model) {
        this.brand = brand;
        this.model = model;
    }
}
let car = new Car('Toyota', 'Camry'); // Объект
