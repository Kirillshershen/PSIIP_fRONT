class Person {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
}

let person = new Person('John', 30); // Создание объекта класса
console.log(person.name); // John
console.log(person.age);  // 30
